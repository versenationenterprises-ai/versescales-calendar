# How to Deploy Your 60 Reels Calendar to versescales.com

This guide will walk you through hosting your HTML file using **GitHub Pages** (which is completely free) and connecting it to your **Porkbun** domain (`versescales.com`). 

I have prepared the files you need. The `index.html` file is your renamed HTML document, and the `CNAME` file tells GitHub which domain to use.

## Step 1: Create a GitHub Repository

1. Log into your GitHub account (`versenationenterprises-ai`).
2. Click the **+** icon in the top right corner and select **New repository**.
3. Name the repository something like `versescales-calendar`.
4. Keep it set to **Public** (GitHub Pages requires public repos for free accounts).
5. Check the box that says **Add a README file** (this initializes the repository).
6. Click **Create repository**.

## Step 2: Upload Your Files to GitHub

1. In your new repository, click the **Add file** button and select **Upload files**.
2. Drag and drop the two files I provided (`index.html` and `CNAME`) into the upload area.
3. Scroll down and click **Commit changes** (the default commit message is fine).

## Step 3: Enable GitHub Pages

1. In your repository, click the **Settings** tab at the top.
2. In the left sidebar, scroll down and click on **Pages**.
3. Under **Build and deployment**, ensure the **Source** is set to **Deploy from a branch**.
4. Under **Branch**, select `main` from the dropdown, and leave the folder as `/ (root)`. Click **Save**.
5. Scroll down to the **Custom domain** section. You should see `versescales.com` already filled in (because of the `CNAME` file we uploaded). If it's not there, type `versescales.com` and click **Save**.
6. GitHub will now attempt to verify your domain. It will fail initially because we haven't set up Porkbun yet. That's normal. Leave this tab open.

## Step 4: Configure Porkbun DNS

Now we need to tell Porkbun to point your domain to GitHub's servers.

1. Log into your **Porkbun** account and go to your **Domain Management** dashboard.
2. Find `versescales.com` and click on the **DNS** icon (it looks like a small gear or the letters DNS).
3. **Delete existing A or CNAME records:** If there are any existing records for the blank host (often shown as `@` or just blank) or for `www`, delete them to avoid conflicts.
4. **Add GitHub's A Records:** You need to add four A records pointing to GitHub's IP addresses.
   - **Type:** `A`
   - **Host:** (leave blank)
   - **Answer:** `185.199.108.153`
   - Click **Add**.
   
   Repeat this for the other three IP addresses:
   - `185.199.109.153`
   - `185.199.110.153`
   - `185.199.111.153`

5. **Add the CNAME Record for www:**
   - **Type:** `CNAME`
   - **Host:** `www`
   - **Answer:** `versenationenterprises-ai.github.io`
   - Click **Add**.

## Step 5: Final Verification

1. Go back to your GitHub repository's **Settings > Pages** tab.
2. Wait a few minutes (DNS propagation can sometimes take a little while, though Porkbun is usually fast).
3. Under the **Custom domain** section, check the box that says **Enforce HTTPS** (this gives your site the secure padlock icon). If it's greyed out, wait 15-30 minutes and try again.
4. Once the DNS propagates, your site will be live at `https://versescales.com`!

---

**Note:** DNS changes can sometimes take up to 24-48 hours to fully propagate across the globe, but typically you will see it working within 15-30 minutes.
